exp=$1

Rscript plot_power_ss.r 0 $exp
Rscript plot_power_ss.r 0.001 $exp
Rscript plot_power_ss.r 0.002 $exp
Rscript plot_power_ss.r 0.02 $exp
Rscript plot_power_ss.r 0.2 $exp
