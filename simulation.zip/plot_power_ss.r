args=commandArgs(trailingOnly=TRUE)
library(ggplot2)
library(RColorBrewer)
cis=0.1
#for(trans in c(0.02,0.05,0.1,0.2,0.5)){
trans=as.numeric(args[1])
exp=as.numeric(args[2])
power=NULL
indicator=NULL
for(p in c(0.005,0.01,0.05)){
	for(n in c(200,400,600,800,900)){
		dat=NULL
		for(iter in 1:2){
			temp=read.table(paste("./output/luijk/heavy_tail",exp,"/iter",iter,"_luijk_N",n,"_trans_h2_",trans,"_cis_h2_",cis,"_p",p,"_pval.txt",sep=""),header=T)
			dat=rbind(dat,temp)
			}
		power=c(power,length(which(dat$gbat_pval<0.05/(15000*5000)))/2000,length(which(dat$iinv_pval<0.05/(15000*5000)))/2000,length(which(dat$snp_pval<0.05/(15000*1000000)))/2000,length(which(dat$sing_snp_pval<0.05/(15000*5000)))/2000,length(which(dat$gbat_old_pval<0.05/(15000*5000)))/2000)
		indicator=c(indicator,"GBAT","iinv","SNP-based","top-cis-SNP","uncorrected_GBAT")


	}
	
}
outp=c(rep("0.5%",25),rep("1%",25),rep("5%",25))
outtrans=c(200,200,200,200,200,400,400,400,400,400,600,600,600,600,600,800,800,800,800,800,900,900,900,900,900,200,200,200,200,200,400,400,400,400,400,600,600,600,600,600,800,800,800,800,800,900,900,900,900,900,200,200,200,200,200,400,400,400,400,400,600,600,600,600,600,800,800,800,800,800,900,900,900,900,900)
#outtrans=c(200,200,400,400,600,600,800,800,900,900,200,200,400,400,600,600,800,800,900,900,200,200,400,400,600,600,800,800,900,900)
#outtrans=c(0.02,0.02,0.05,0.05,0.1,0.1,0.2,0.2,0.5,0.5,0.02,0.02,0.05,0.05,0.1,0.1,0.2,0.2,0.5,0.5,0.02,0.02,0.05,0.05,0.1,0.1,0.2,0.2,0.5,0.5)
data=data.frame(Sample_size=outtrans,proportion_causal=outp,Power=power,Method=indicator)
pdf(paste("power_plot_heavy_tail",exp,"_trans_",trans,"_nontyped",trans,"_cis0.1_dinv_iinv.pdf",sep=""),5.5,4)
col=brewer.pal(8,"Dark2")[c(2,5,6,7,8)]
ggplot(data,aes(x=Sample_size,y=Power,shape=proportion_causal,color=Method))+geom_point(size=3)+geom_line(linetype = "dotted",size=0.2)+theme(panel.background = element_rect(fill='white', colour='black'), axis.ticks = element_line(colour = 'black'), axis.text = element_text(size = 14, colour = 'black'), axis.text.x = element_text(angle = 0, hjust = 0.5),axis.title = element_text(size = 16, colour = 'black'), strip.background = element_rect(fill = 'lightblue'), panel.grid.minor = element_blank())+scale_color_manual(values =  col)+ scale_y_continuous(labels = scales::percent)
#+coord_cartesian(ylim=c(0,0.3))

dev.off()

